import { Component, OnInit } from '@angular/core';
import { DbcommunicatorService } from 'src/app/dbcommunicator.service';

@Component({
  selector: 'app-centerview',
  templateUrl: './centerview.component.html',
  styleUrls: ['./centerview.component.css']
})
export class CenterviewComponent implements OnInit {

  constructor(private service:DbcommunicatorService) { }

Storetweet:any;

  ngOnInit() {
    this.service.gettweet().subscribe((data)=>{console.log(data)
    })
    console.log(this.Storetweet)
  }

}
