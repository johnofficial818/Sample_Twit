import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leftview',
  templateUrl: './leftview.component.html',
  styleUrls: ['./leftview.component.css']
})
export class LeftviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
