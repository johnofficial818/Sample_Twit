import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LeftviewComponent } from './Mainpage/leftview/leftview.component';
import { RightviewComponent } from './Mainpage/rightview/rightview.component';
import { CenterviewComponent } from './Mainpage/centerview/centerview.component';
import { DemoMaterialModule } from 'src/material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatIconModule} from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { DbcommunicatorService } from './dbcommunicator.service';





@NgModule({
  declarations: [
    AppComponent,
    LeftviewComponent,
    RightviewComponent,
    CenterviewComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    DemoMaterialModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [DbcommunicatorService],
  bootstrap: [AppComponent]
})
export class AppModule { }
