import { TestBed } from '@angular/core/testing';

import { DbcommunicatorService } from './dbcommunicator.service';

describe('DbcommunicatorService', () => {
  let service: DbcommunicatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DbcommunicatorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
