import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rightview',
  templateUrl: './rightview.component.html',
  styleUrls: ['./rightview.component.css']
})
export class RightviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
